This soundfont is meant for casual listening, however, you can make compositions with it as well. You can load it up on programs like Foobar2000, or Droidsound-E (on Android), or any other program that can load up soundfonts automatically.

Soundfont created by PablosCorner.

https://www.youtube.com/pabloscorner

------------
Thread for support:
https://www.smwcentral.net/?p=viewthread&t=88116